---
title: "cran-comments"
author: "Zhengguo"
date: "June 23, 2017"
output: html_document
---

## Test environment
* windows 10, R 3.4.0
* mac OS X 10.12.15, R 3.4.0
* Ubuntu server (on Travis), R 3.4.0

## R CMD check results
R CMD check results
0 errors  0 warnings  0 notes

R CMD check succeeded 
