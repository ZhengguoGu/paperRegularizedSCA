---
title: "NEWS"
author: "Zhengguo"
date: "6/23/2017"
output: html_document
---
# RegularizedSCA v0.5.0
S3 methods have been included in the package. Now, the summary() function can be used together with the following functions:

+ cv_sparseSCA()
+ cv_structuredSCA()
+ DISCOsca()
+ sparseSCA()
+ structuredSCA()
+ undoShrinkage()
+ VAF()

The plot() function can be used together with the following functions:

+ cv_sparseSCA()
+ cv_structuredSCA()

# RegularizedSCA v0.4.2
Note that the previous versions are not on CRAN. As of v0.4.2, all the changes will be documented in this file.